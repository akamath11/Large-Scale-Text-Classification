from sklearn.datasets import load_svmlight_file
import numpy as np

X,Y = load_svmlight_file("data/realsim.scale.trn.libsvm")
X_test,Y_test = load_svmlight_file("data/realsim.scale.tst.libsvm")
#X1=X_test.todense()
Y1=Y_test
#X=X.todense()
Grad_norm=[]
grad_norm=[]
Accuracy=[]
Relative_func_val=[]

w=np.matrix(np.zeros(X.shape[1])).T

import timeit
start_time = timeit.default_timer()


def gradient(w,lamda,y,f,x):
    n=len(y)
    A=np.ndarray.flatten(np.array(x*w))
    I=np.array(range(len(A)))
    select=(1-y*A)>0
    I=I[select]
    XI=x[I]
    YI=y[I]
    grad=np.array(w).flatten()+2.0/n*lamda*XI.T*(np.array(XI*w).flatten()-YI)
    grad_norm.append(np.linalg.norm(grad))

    return grad
    
def loss_cal(w,y,x):
    #N=len(y)
    
    Y2=1-np.multiply(y,np.array(x*w).flatten())
    Y2[Y2<0]=0
    loss=np.sum(np.array(Y2)**2)
    return loss
    
    
def test_accuracy(w,y_test,x_test):
    f=x_test*w
    y_predict=np.ones(len(f))*-1
    a=np.ndarray.flatten(np.array(f>0))
    y_predict[a]=1
    accuracy=float(np.sum(y_predict==y_test))/len(y_test)
    return accuracy 
    

    
# Main code body
    
X_train=X
Y_train=Y
minibatchsize=10
#lamda=3631.3203125
lamda=7230.875

#True_val=2542.143631
True_val=680.537008

#Initialization

w=np.matrix(np.zeros(X_train.shape[1])).T
old_w=w
num_iterations=0


gamma=0.00002
Train_time=[]
max_iterations=15
converged=False
old_loss=99999
beta=0.01
while(num_iterations<max_iterations and not converged):
    Total_loss=0
    num_iterations=num_iterations+1
    A=np.array(range(len(Y)))
    np.random.shuffle(A)
    X=X[A]
    Y=Y[A]
    step_size=gamma/(1+beta*num_iterations)
    for i in range(0,len(Y_train)-minibatchsize,minibatchsize):
        X_n=X_train[i:i + minibatchsize]
        Y_n=Y_train[i:i + minibatchsize]
        F_n= X_n*w
        g=gradient(w,lamda,Y_n,F_n,X_n)
        
        w=w-step_size*np.matrix(g).T
        
       
        loss=loss_cal(w,Y_n,X_n)
        Total_loss=Total_loss+loss
        
    time_elapsed = timeit.default_timer() - start_time  
    Train_time.append(time_elapsed)    
    func_val=lamda*float(Total_loss)/len(Y_train)+0.5*w.T*w
    
    relative_func_val=(float(func_val)-True_val)/True_val
    Relative_func_val.append(relative_func_val)
    print('relative function value at ' + str(num_iterations) + ' :' + str(relative_func_val))
    print('loss at epoch ' + str(num_iterations) + ' :' + str(float(Total_loss)/len(Y_train)))
    accuracy=test_accuracy(w,Y_test,X_test)
    Accuracy.append(accuracy)
    print('test accuracy at ' + str(num_iterations) + ' :' + str(accuracy))
    Grad_norm.append(np.mean(np.array(grad_norm)))
    print('Grad norm: ' + str(np.mean(np.array(grad_norm))))
    old_loss=Total_loss
    

        
import matplotlib.pyplot as plt  
Iterations=Train_time
plt.plot(Iterations,Grad_norm)
plt.plot(Iterations, Accuracy)
plt.plot(Iterations, Relative_func_val)      


        
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    