import ConjugateGradient
from sklearn.datasets import load_svmlight_file
import numpy as np

import timeit
start_time = timeit.default_timer()

X,Y = load_svmlight_file("data/realsim.scale.trn.libsvm")
X_test,Y_test = load_svmlight_file("data/realsim.scale.tst.libsvm")


lamda=7230.875
#lamda=3631.3203125

True_val=680.537008
#True_val=2542.143631

Train_time=[]

w=np.matrix(np.zeros(X.shape[1])).T


A=np.ndarray.flatten(np.array(X*w))
I=np.array(range(len(A)))
select=(1-Y*A)>0
I=I[select]



def gradient(X,Y,w,lamda):
    N=len(Y)
    XI=X[I]
    YI=Y[I]
    return 2*lamda/N*XI.T*(np.array(XI*w).flatten()-YI)
   
    
def loss_cal(w,Y,X):
#    loss=loss+np.float(max((1-y[i]*x[i]*w),0))**2
    N=len(Y)
    Y1=np.matrix(Y).T
    Y2=1-np.multiply(Y1,X*w)
    Y2[Y2<0]=0
    loss=np.sum(np.array(Y2)**2)/N
    return loss
    
    

    
def test_accuracy(w,y_test,x_test):
    f=X_test*w
    y_predict=np.ones(len(f))*-1
    a=np.ndarray.flatten(np.array(f>0))
    y_predict[a]=1
    accuracy=float(np.sum(y_predict==y_test))/len(y_test)
    return accuracy 

num_iterations=0
max_iterations=6

Relative_func_val=[]
Accuracy=[]
Loss=[]
Grad_norm=[]
while(num_iterations<max_iterations):
#    index=random.randint(0, len(Y)-1)
#    Xn=X[index]
#    Yn=Y[index]
    
    grad=gradient(X,Y,w,lamda)
    
    grad=np.array(grad).flatten()
    
    Grad_norm.append(np.linalg.norm(grad))
    d=ConjugateGradient.ConjugateGradient(X, I, grad)
    step=0.2/(1+num_iterations**2)
    d1=step*d[0]
    
    
    
    w=w+np.matrix(d1).T
    
    num_iterations=num_iterations+1
    
    loss=loss_cal(w,Y,X)
    
    time_elapsed = timeit.default_timer() - start_time  
    Train_time.append(time_elapsed)
    print('Loss: '+ str(loss) )
    Loss.append(loss)
    func_val=lamda*loss+0.5*w.T*w
    relative_func_val=(float(func_val)-True_val)/True_val
    Relative_func_val.append(relative_func_val)
    print('Relative function value: '+ str(relative_func_val) )
    accuracy=test_accuracy(w,Y_test,X_test)
    print('Accuracy: '+ str(accuracy))
    Accuracy.append(accuracy)
    
  
  
import matplotlib.pyplot as plt  
Iterations=Train_time
plt.plot(Iterations,Grad_norm)
plt.plot(Iterations, Accuracy)
plt.plot(Iterations, Relative_func_val)
            











    